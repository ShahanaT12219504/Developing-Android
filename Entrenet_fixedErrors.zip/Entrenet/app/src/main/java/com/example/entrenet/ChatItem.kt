data class ChatItem(
    val name: String,
    val message: String,
    val imageResId: Int
)
