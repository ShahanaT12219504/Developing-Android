package com.example.entrenet

import android.net.Uri

data class Post(val content: String)

